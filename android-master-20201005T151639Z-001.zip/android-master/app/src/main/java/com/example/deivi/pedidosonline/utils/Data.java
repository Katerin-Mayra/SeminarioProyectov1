package com.example.deivi.pedidosonline.utils;

import java.util.ArrayList;

import collections.Menus;

public class Data {


    public static String TOKEN = "Data eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJuYW1lIjoiZGVpdmlkMTM0NTZAZ21haWwuY29tIiwicGFzc3dvcmQiOiIxMiIsImlhdCI6MTU0NDIyMDMzOX0.SrZWEwHM0BUNp5o98g0fipyX5x7SRcCXr_dkfCMrnYs";
    public static String FOTO="http://192.168.1.102:7777";
    public static  String  HOST  = "http://192.168.1.102:7777/api/v1.0";
    public static  String  REGISTER_RESTORANT = HOST + "/restaurant";
    public static String UPLOAD_RESTORANT = HOST + "/uploadrestaurant";
    public static  String  REGISTER_MENUS = HOST + "/menus";
    public static  String  REGISTER_CLIENTE = HOST + "/cliente";
    public static  String  REGISTER_LOGIN = HOST + "/login";
    public static String ID_User="0";
    public static String ID_RESTORANT="0";

    public static String ID_Menus = "0";
    public  static String Tipo="";


}
