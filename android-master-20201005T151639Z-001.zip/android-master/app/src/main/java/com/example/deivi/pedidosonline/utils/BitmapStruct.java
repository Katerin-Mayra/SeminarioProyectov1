package com.example.deivi.pedidosonline.utils;

import android.graphics.Bitmap;

public class BitmapStruct {
    public Bitmap img;
    public String path;
}
