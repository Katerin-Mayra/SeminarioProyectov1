package collections;

public class item2 {
    public String nombre ;
    public String url2 ;
    public int id ;

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public void setUrl2(String url) {
        this.url2 = url;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getNombre() {
        return this.nombre;
    }

    public int getId() {
        return this.id;
    }

    public String getUrl2() {
        return this.url2;
    }
}
