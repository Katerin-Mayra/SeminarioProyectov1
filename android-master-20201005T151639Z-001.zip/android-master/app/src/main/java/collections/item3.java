package collections;

public class item3 {
    public String nombre;
    public String nit;
    public String propietario;
    public String telefono;
    public String calle;
    public String image;
    public String id1;

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public void setNit(String nit) {
        this.nit = nit;
    }

    public void setPropietario(String propietario) {
        this.propietario = propietario;
    }

    public void setTelefono(String telefono) {
        this.telefono = telefono;
    }

    public void setCalle(String calle) {
        this.calle = calle;
    }

    public void setImage(String image) {
        this.image = image;
    }

    public void setId(String id1) {
        this.id1 = id1;
    }

    public String getNombre() {
        return this.nombre;
    }

    public String getNit() {
        return this.nit;
    }

    public String getPropietario() {
        return this.propietario;
    }

    public String getTelefono() {
        return this.telefono;
    }

    public String getCalle() {
        return this.calle;
    }

    public String getImage() {
        return this.image;
    }

    public String getId1() {
        return this.id1;
    }
}
