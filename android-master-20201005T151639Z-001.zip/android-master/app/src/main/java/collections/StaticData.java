package collections;

import java.util.ArrayList;

public class StaticData {
    public static ArrayList<Menus> LISTAPARCIAL;
}
